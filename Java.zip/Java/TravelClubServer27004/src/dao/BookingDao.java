package dao;

import model.Booking;
import model.EBookingStatus;
import util.HibernateUtil;
import java.util.Collections;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class BookingDao implements IBookingDao {

    @Override
    public Booking save(Booking booking) {
        Transaction tx = null;
        Session s = HibernateUtil.getSessionFactory().openSession();
        try {
            tx = s.beginTransaction();
            s.save(booking);
            tx.commit();
            s.evict(booking);
            return booking;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return null;
        } finally { s.close(); }
    }

    @Override
    public Booking update(Booking booking) {
        Transaction tx = null;
        Session s = HibernateUtil.getSessionFactory().openSession();
        try {
            tx = s.beginTransaction();
            s.update(booking);
            tx.commit();
            s.evict(booking);
            return booking;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return null;
        } finally { s.close(); }
    }

    @Override
    public boolean delete(int id) {
        Transaction tx = null;
        Session s = HibernateUtil.getSessionFactory().openSession();
        try {
            tx = s.beginTransaction();
            Booking b = (Booking) s.get(Booking.class, id);
            if (b != null) { s.delete(b); tx.commit(); return true; }
            return false;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return false;
        } finally { s.close(); }
    }

    @Override
    public Booking findById(int id) {
        Session s = HibernateUtil.getSessionFactory().openSession();
        try {
            Booking b = (Booking) s.get(Booking.class, id);
            if (b != null) {
                // force-load eager associations then evict
                if (b.getUser() != null) b.getUser().getUserId();
                if (b.getTrip() != null) b.getTrip().getTripId();
                s.evict(b);
            }
            return b;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally { s.close(); }
    }

    @Override
    public List<Booking> findAll() {
        Session s = HibernateUtil.getSessionFactory().openSession();
        try {
            List<Booking> list = s.createQuery("FROM Booking ORDER BY bookingDate DESC").list();
            list.forEach(s::evict);
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        } finally { s.close(); }
    }

    @Override
    public List<Booking> findByUserId(int userId) {
        Session s = HibernateUtil.getSessionFactory().openSession();
        try {
            List<Booking> list = s.createQuery(
                "FROM Booking WHERE user.userId = :uid ORDER BY bookingDate DESC")
                .setParameter("uid", userId).list();
            list.forEach(s::evict);
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        } finally { s.close(); }
    }

    @Override
    public List<Booking> findByTripId(int tripId) {
        Session s = HibernateUtil.getSessionFactory().openSession();
        try {
            List<Booking> list = s.createQuery(
                "FROM Booking WHERE trip.tripId = :tid ORDER BY bookingDate DESC")
                .setParameter("tid", tripId).list();
            list.forEach(s::evict);
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        } finally { s.close(); }
    }

    @Override
    public List<Booking> findByStatus(EBookingStatus status) {
        Session s = HibernateUtil.getSessionFactory().openSession();
        try {
            List<Booking> list = s.createQuery(
                "FROM Booking WHERE status = :st ORDER BY bookingDate DESC")
                .setParameter("st", status).list();
            list.forEach(s::evict);
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        } finally { s.close(); }
    }
}
