package dao;

import model.Booking;
import model.EBookingStatus;
import java.util.List;

/**
 * IBookingDao interface
 * FIX: findByStatus parameter changed from String to EBookingStatus
 */
public interface IBookingDao extends IGenericDao<Booking> {
    List<Booking> findByUserId(int userId);
    List<Booking> findByTripId(int tripId);
    List<Booking> findByStatus(EBookingStatus status); // FIX: was String
}
