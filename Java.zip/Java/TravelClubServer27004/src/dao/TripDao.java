package dao;

import model.Trip;
import util.HibernateUtil;
import java.util.Collections;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class TripDao implements ITripDao {

    @Override
    public Trip save(Trip trip) {
        Transaction tx = null;
        Session s = HibernateUtil.getSessionFactory().openSession();
        try {
            tx = s.beginTransaction();
            s.save(trip);
            tx.commit();
            s.evict(trip);
            return trip;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            System.err.println("[TripDao.save] ERROR: " + e.getMessage());
            e.printStackTrace();
            return null;
        } finally { s.close(); }
    }

    @Override
    public Trip update(Trip trip) {
        Transaction tx = null;
        Session s = HibernateUtil.getSessionFactory().openSession();
        try {
            tx = s.beginTransaction();
            s.update(trip);
            tx.commit();
            s.evict(trip);
            return trip;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            System.err.println("[TripDao.update] ERROR: " + e.getMessage());
            e.printStackTrace();
            return null;
        } finally { s.close(); }
    }

    @Override
    public boolean delete(int id) {
        Transaction tx = null;
        Session s = HibernateUtil.getSessionFactory().openSession();
        try {
            tx = s.beginTransaction();
            Trip t = (Trip) s.get(Trip.class, id);
            if (t != null) { s.delete(t); tx.commit(); return true; }
            return false;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return false;
        } finally { s.close(); }
    }

    @Override
    public Trip findById(int id) {
        Session s = HibernateUtil.getSessionFactory().openSession();
        try {
            Trip t = (Trip) s.get(Trip.class, id);
            if (t != null) s.evict(t);
            return t;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally { s.close(); }
    }

    @Override
    public List<Trip> findAll() {
        Session s = HibernateUtil.getSessionFactory().openSession();
        try {
            List<Trip> list = s.createQuery("FROM Trip ORDER BY departureDate").list();
            list.forEach(s::evict);
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        } finally { s.close(); }
    }

    @Override
    public List<Trip> findByDestination(String destination) {
        Session s = HibernateUtil.getSessionFactory().openSession();
        try {
            List<Trip> list = s.createQuery(
                "FROM Trip WHERE LOWER(destination) LIKE :d OR LOWER(country) LIKE :d ORDER BY departureDate")
                .setParameter("d", "%" + destination.toLowerCase() + "%").list();
            list.forEach(s::evict);
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        } finally { s.close(); }
    }

    @Override
    public List<Trip> findActiveTrips() {
        Session s = HibernateUtil.getSessionFactory().openSession();
        try {
            List<Trip> list = s.createQuery(
                "FROM Trip WHERE status = 'ACTIVE' AND availableSlots > 0 ORDER BY departureDate").list();
            list.forEach(s::evict);
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        } finally { s.close(); }
    }
}
