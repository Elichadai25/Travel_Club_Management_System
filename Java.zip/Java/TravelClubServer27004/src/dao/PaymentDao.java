/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.Collections;
import java.util.List;
import model.Payment;
import org.hibernate.*;
import util.HibernateUtil;

/**
 *
 * @author elichadai
 */
public class PaymentDao {
    // CRUD operations
    public Payment registerPayment(Payment paymentObj){
        try{
            Session ss = HibernateUtil.getSessionFactory().openSession();
            Transaction tr = ss.beginTransaction();
            ss.save(paymentObj);
            tr.commit();
            ss.close();
            return paymentObj;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        
        return null;
    }
    public Payment updatePayment(Payment paymentObj){
        try{
            Session ss = HibernateUtil.getSessionFactory().openSession();
            Transaction tr = ss.beginTransaction();
            ss.update(paymentObj);
            tr.commit();
            ss.close();
            return paymentObj;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        
        return null;
    }
    
    public Payment deletePayment(Payment paymentObj){
        try{
            Session ss = HibernateUtil.getSessionFactory().openSession();
            Transaction tr = ss.beginTransaction();
            ss.delete(paymentObj);
            tr.commit();
            ss.close();
            return paymentObj;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        
        return null;
    }
    
    public Payment findPaymentById(Payment paymentObj){
        try{
            Session ss = HibernateUtil.getSessionFactory().openSession();
          Payment found = (Payment) ss.get(
        Payment.class,
        paymentObj.getPaymentId());
            ss.close();
            return found;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return null;
    }
    
    public List<Payment> findAllPayments(){
        try{
            Session ss = HibernateUtil.getSessionFactory().openSession();
            List<Payment> payments = ss.createQuery("SELECT payment FROM Payment payment").list();
            ss.close();
            return payments;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        
        return Collections.EMPTY_LIST;
    }

    public Payment save(Payment payment) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Payment update(Payment payment) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Payment findById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public List<Payment> findAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Payment findByBookingId(int bookingId) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
