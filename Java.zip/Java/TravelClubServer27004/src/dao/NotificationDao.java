package dao;

import model.Notification;
import util.HibernateUtil;
import java.util.Collections;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class NotificationDao implements INotificationDao {

    @Override
    public Notification save(Notification n) {
        Transaction tx = null;
        Session s = HibernateUtil.getSessionFactory().openSession();
        try {
            tx = s.beginTransaction();
            s.save(n);
            tx.commit();
            s.evict(n);
            return n;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return null;
        } finally { s.close(); }
    }

    @Override
    public Notification update(Notification n) {
        Transaction tx = null;
        Session s = HibernateUtil.getSessionFactory().openSession();
        try {
            tx = s.beginTransaction();
            s.update(n);
            tx.commit();
            s.evict(n);
            return n;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return null;
        } finally { s.close(); }
    }

    @Override
    public boolean delete(int id) {
        Transaction tx = null;
        Session s = HibernateUtil.getSessionFactory().openSession();
        try {
            tx = s.beginTransaction();
            Notification n = (Notification) s.get(Notification.class, id);
            if (n != null) { s.delete(n); tx.commit(); return true; }
            return false;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return false;
        } finally { s.close(); }
    }

    @Override
    public Notification findById(int id) {
        Session s = HibernateUtil.getSessionFactory().openSession();
        try {
            Notification n = (Notification) s.get(Notification.class, id);
            if (n != null) s.evict(n);
            return n;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally { s.close(); }
    }

    @Override
    public List<Notification> findAll() {
        Session s = HibernateUtil.getSessionFactory().openSession();
        try {
            List<Notification> list = s.createQuery("FROM Notification ORDER BY sentAt DESC").list();
            list.forEach(s::evict);
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        } finally { s.close(); }
    }

    @Override
    public List<Notification> findByUserId(int userId) {
        Session s = HibernateUtil.getSessionFactory().openSession();
        try {
            List<Notification> list;
            if (userId == 0) {
                list = s.createQuery("FROM Notification ORDER BY sentAt DESC").list();
            } else {
                list = s.createQuery("FROM Notification WHERE user.userId = :uid ORDER BY sentAt DESC")
                        .setParameter("uid", userId).list();
            }
            list.forEach(s::evict);
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        } finally { s.close(); }
    }

    @Override
    public List<Notification> findUnreadByUserId(int userId) {
        Session s = HibernateUtil.getSessionFactory().openSession();
        try {
            List<Notification> list = s.createQuery(
                "FROM Notification WHERE user.userId = :uid AND read = false ORDER BY sentAt DESC")
                .setParameter("uid", userId).list();
            list.forEach(s::evict);
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        } finally { s.close(); }
    }
}
