package service.Impl;

import dao.BookingDao;
import dao.NotificationDao;
import dao.PaymentDaoImpl;
import dao.TripDao;
import dao.UserDao;
import model.Booking;
import model.EBookingStatus;
import model.Notification;
import model.Payment;
import model.Trip;
import model.User;
import rmi.ITravelClubService;
import service.GmailOtpService;
import service.MessageBrokerService;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class TravelClubServiceImpl extends UnicastRemoteObject implements ITravelClubService {

    private final UserDao userDao           = new UserDao();
    private final TripDao tripDao           = new TripDao();
    private final BookingDao bookingDao     = new BookingDao();
    private final PaymentDaoImpl paymentDao = new PaymentDaoImpl();
    private final NotificationDao notifDao  = new NotificationDao();
    private final MessageBrokerService broker = MessageBrokerService.getInstance();

    private final Map<String, String> otpStore = new HashMap<>();

    public TravelClubServiceImpl() throws RemoteException { super(); }

    // ── Detach helpers: clear Hibernate lazy proxies before RMI serialization ──

    private User detachUser(User u) {
        if (u != null) { u.setBookings(null); u.setWishlist(null); }
        return u;
    }

    private Trip detachTrip(Trip t) {
        if (t != null) { t.setBookings(null); t.setInterestedUsers(null); }
        return t;
    }

    private Booking detachBooking(Booking b) {
        if (b == null) return null;
        if (b.getUser() != null) detachUser(b.getUser());
        if (b.getTrip() != null) detachTrip(b.getTrip());
        b.setPayment(null);
        return b;
    }

    private Payment detachPayment(Payment p) {
        if (p == null) return null;
        if (p.getBooking() != null) detachBooking(p.getBooking());
        return p;
    }

    private Notification detachNotification(Notification n) {
        if (n != null && n.getUser() != null) detachUser(n.getUser());
        return n;
    }

    // USER 

    @Override
    public User registerUser(User user) throws RemoteException {
        return detachUser(userDao.save(user));
    }

    @Override
    public User updateUser(User user) throws RemoteException {
        return detachUser(userDao.update(user));
    }

    @Override
    public boolean deleteUser(int id) throws RemoteException {
        return userDao.delete(id);
    }

    @Override
    public User findUserById(int id) throws RemoteException {
        return detachUser(userDao.findById(id));
    }

    @Override
    public List<User> findAllUsers() throws RemoteException {
        List<User> list = userDao.findAll();
        list.forEach(this::detachUser);
        return list;
    }

    @Override
    public User login(String email, String password) throws RemoteException {
        return detachUser(userDao.findByEmailAndPassword(email, password));
    }

    @Override
    public boolean emailExists(String email) throws RemoteException {
        return userDao.emailExists(email);
    }

    @Override
    public boolean phoneExists(String phone) throws RemoteException {
        return userDao.phoneExists(phone);
    }

    // TRIP 

    @Override
    public Trip saveTrip(Trip trip) throws RemoteException {
        try {
            System.out.println("[Server] saveTrip called: " + trip.getDestination() + ", " + trip.getCountry());
            Trip saved = tripDao.save(trip);
            if (saved != null) {
                System.out.println("[Server] Trip saved with ID: " + saved.getTripId());
                return detachTrip(saved);
            } else {
                System.out.println("[Server] TripDao.save returned null");
                throw new RemoteException("Database save failed. Check server console for Hibernate errors.");
            }
        } catch (RemoteException re) {
            throw re;
        } catch (Exception e) {
            System.err.println("[Server] saveTrip exception: " + e.getMessage());
            e.printStackTrace();
            throw new RemoteException("Save failed: " + e.getMessage(), e);
        }
    }

    @Override
    public Trip updateTrip(Trip trip) throws RemoteException {
        return detachTrip(tripDao.update(trip));
    }

    @Override
    public boolean deleteTrip(int id) throws RemoteException {
        return tripDao.delete(id);
    }

    @Override
    public Trip findTripById(int id) throws RemoteException {
        return detachTrip(tripDao.findById(id));
    }

    @Override
    public List<Trip> findAllTrips() throws RemoteException {
        List<Trip> list = tripDao.findAll();
        list.forEach(this::detachTrip);
        return list;
    }

    @Override
    public List<Trip> searchTrips(String destination) throws RemoteException {
        List<Trip> list = tripDao.findByDestination(destination);
        list.forEach(this::detachTrip);
        return list;
    }

    @Override
    public List<Trip> findActiveTrips() throws RemoteException {
        List<Trip> list = tripDao.findActiveTrips();
        list.forEach(this::detachTrip);
        return list;
    }

    // ===================== BOOKING =====================

    @Override
    public Booking createBooking(Booking booking) throws RemoteException {
        Trip trip = tripDao.findById(booking.getTrip().getTripId());
        if (trip == null)
            throw new RemoteException("Trip not found.");
        if (trip.getAvailableSlots() < booking.getNumSeats())
            throw new RemoteException("Not enough slots. Only " + trip.getAvailableSlots() + " left.");
        if (!"ACTIVE".equals(trip.getStatus()))
            throw new RemoteException("This trip is no longer active.");

        Booking saved = bookingDao.save(booking);
        if (saved != null) {
            trip.setAvailableSlots(trip.getAvailableSlots() - booking.getNumSeats());
            tripDao.update(trip);
            String msg = "Your booking #" + saved.getBookingId() + " for " + trip.getDestination() + " is confirmed!";
            notifDao.save(new Notification(msg, "BOOKING", booking.getUser()));
            broker.sendNotificationEvent("BOOKING", booking.getUser().getUserId(), msg);
        }
        return detachBooking(saved);
    }

    @Override
    public Booking updateBooking(Booking booking) throws RemoteException {
        return detachBooking(bookingDao.update(booking));
    }

    @Override
    public boolean deleteBooking(int id) throws RemoteException {
        Booking b = bookingDao.findById(id);
        if (b != null && EBookingStatus.PENDING == b.getStatus()) {
            Trip trip = tripDao.findById(b.getTrip().getTripId());
            if (trip != null) {
                trip.setAvailableSlots(trip.getAvailableSlots() + b.getNumSeats());
                tripDao.update(trip);
            }
        }
        return bookingDao.delete(id);
    }

    @Override
    public Booking findBookingById(int id) throws RemoteException {
        return detachBooking(bookingDao.findById(id));
    }

    @Override
    public List<Booking> findAllBookings() throws RemoteException {
        List<Booking> list = bookingDao.findAll();
        list.forEach(this::detachBooking);
        return list;
    }

    @Override
    public List<Booking> findBookingsByUser(int userId) throws RemoteException {
        List<Booking> list = bookingDao.findByUserId(userId);
        list.forEach(this::detachBooking);
        return list;
    }

    @Override
    public List<Booking> findBookingsByTrip(int tripId) throws RemoteException {
        List<Booking> list = bookingDao.findByTripId(tripId);
        list.forEach(this::detachBooking);
        return list;
    }

    // ===================== PAYMENT =====================

    @Override
    public Payment createPayment(Payment payment) throws RemoteException {
        Payment existing = paymentDao.findByBookingId(payment.getBooking().getBookingId());
        if (existing != null)
            throw new RemoteException("Payment already exists for booking #" + payment.getBooking().getBookingId());

        Payment saved = paymentDao.save(payment);
        if (saved != null) {
            Booking b = bookingDao.findById(payment.getBooking().getBookingId());
            if (b != null) {
                b.setStatus(EBookingStatus.CONFIRMED);
                bookingDao.update(b);
                String msg = "Payment of $" + String.format("%.2f", payment.getAmount())
                        + " received. Ref: " + payment.getTransactionRef();
                notifDao.save(new Notification(msg, "PAYMENT", b.getUser()));
                broker.sendNotificationEvent("PAYMENT", b.getUser().getUserId(), msg);
            }
        }
        return detachPayment(saved);
    }

    @Override
    public Payment updatePayment(Payment payment) throws RemoteException {
        return detachPayment(paymentDao.update(payment));
    }

    @Override
    public Payment findPaymentById(int id) throws RemoteException {
        return detachPayment(paymentDao.findById(id));
    }

    @Override
    public List<Payment> findAllPayments() throws RemoteException {
        List<Payment> list = paymentDao.findAll();
        list.forEach(this::detachPayment);
        return list;
    }

    @Override
    public Payment findPaymentByBooking(int bookingId) throws RemoteException {
        return detachPayment(paymentDao.findByBookingId(bookingId));
    }

    @Override
    public double getTotalRevenue() throws RemoteException {
        return paymentDao.getTotalRevenue();
    }

    // NOTIFICATION 

    @Override
    public Notification sendNotification(Notification notification) throws RemoteException {
        return detachNotification(notifDao.save(notification));
    }

    @Override
    public List<Notification> findNotificationsByUser(int userId) throws RemoteException {
        List<Notification> list = notifDao.findByUserId(userId);
        list.forEach(this::detachNotification);
        return list;
    }

    @Override
    public List<Notification> findUnreadNotifications(int userId) throws RemoteException {
        List<Notification> list = notifDao.findUnreadByUserId(userId);
        list.forEach(this::detachNotification);
        return list;
    }

    @Override
    public boolean markAsRead(int notificationId) throws RemoteException {
        Notification n = notifDao.findById(notificationId);
        if (n != null) { n.setRead(true); notifDao.update(n); return true; }
        return false;
    }

    //  OTP 

    @Override
    public String generateOTP(String email) throws RemoteException {
        String otp = String.format("%06d", new Random().nextInt(999999));
        otpStore.put(email, otp);
        boolean sent = GmailOtpService.sendOtp(email, otp);
        System.out.println("╔══════════════════════════════════════╗");
        System.out.println("║         OTP NOTIFICATION             ║");
        System.out.println("║  To : " + email);
        System.out.println("║  OTP: " + otp + (sent ? "  [EMAIL SENT]" : "  [CONSOLE ONLY]") + "  ║");
        System.out.println("╚══════════════════════════════════════╝");
        broker.sendNotificationEvent("OTP", 0, "OTP sent to " + email + " — code: " + otp);
        return otp;
    }

    @Override
    public boolean verifyOTP(String email, String otp) throws RemoteException {
        String stored = otpStore.get(email);
        if (stored != null && stored.equals(otp)) { otpStore.remove(email); return true; }
        return false;
    }
}
