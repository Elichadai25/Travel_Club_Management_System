package service;

import java.util.concurrent.BlockingQueue;

/**
 * NotificationConsumer - listens to the broker queue in a background thread.
 * Consumes notification events published by MessageBrokerService.
 *
 * Uses Java's BlockingQueue (no external JAR required).
 * In production this would connect to ActiveMQ/RabbitMQ.
 */
public class NotificationConsumer implements Runnable {

    private volatile boolean running = true;
    private Thread thread;

    public void start() {
        thread = new Thread(this, "NotificationConsumer");
        thread.setDaemon(true); // stops automatically when server shuts down
        thread.start();
        System.out.println("[Consumer] Notification consumer started. Listening on queue: "
                + MessageBrokerService.QUEUE_NAME);
    }

    @Override
    public void run() {
        BlockingQueue<String> queue = MessageBrokerService.getQueue();
        while (running) {
            try {
                // Blocks until a message arrives (like a real JMS consumer)
                String payload = queue.take();
                processMessage(payload);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

    private void processMessage(String payload) {
        String[] parts = payload.split("\\|", 3);
        String type    = parts.length > 0 ? parts[0] : "UNKNOWN";
        String userId  = parts.length > 1 ? parts[1] : "?";
        String message = parts.length > 2 ? parts[2] : payload;

        System.out.println("╔══════════════════════════════════════════════╗");
        System.out.println("║  [NOTIFICATION EVENT RECEIVED FROM BROKER]   ║");
        System.out.println("║  Queue   : " + MessageBrokerService.QUEUE_NAME);
        System.out.println("║  Type    : " + type);
        System.out.println("║  User ID : " + userId);
        System.out.println("║  Message : " + message);
        System.out.println("╚══════════════════════════════════════════════╝");
    }

    public void stop() {
        running = false;
        if (thread != null) thread.interrupt();
        System.out.println("[Consumer] Notification consumer stopped.");
    }
}
