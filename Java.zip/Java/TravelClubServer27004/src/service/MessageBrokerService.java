package service;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * MessageBrokerService - simulates a message broker using Java's BlockingQueue.
 * No external JAR required. Demonstrates the message broker pattern required by the project.
 *
 * In a production system this would use ActiveMQ/RabbitMQ.
 * The queue name is "travel.notifications" to match the ActiveMQ design.
 */
public class MessageBrokerService {

    public static final String QUEUE_NAME = "travel.notifications";

    // Shared in-memory queue (acts as the message broker queue)
    private static final BlockingQueue<String> queue = new LinkedBlockingQueue<>();

    private static MessageBrokerService instance;

    private MessageBrokerService() {
        System.out.println("[Broker] Message broker initialized. Queue: " + QUEUE_NAME);
    }

    public static MessageBrokerService getInstance() {
        if (instance == null) instance = new MessageBrokerService();
        return instance;
    }

    /**
     * Publishes a notification event to the broker queue.
     * Format: "TYPE|userId|message"
     */
    public void sendNotificationEvent(String type, int userId, String message) {
        try {
            String payload = type + "|" + userId + "|" + message;
            queue.put(payload);
            System.out.println("[Broker] Event published → " + QUEUE_NAME + " | " + payload);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("[Broker] Failed to publish event: " + e.getMessage());
        }
    }

    /**
     * Returns the shared queue so the consumer can poll from it.
     */
    public static BlockingQueue<String> getQueue() {
        return queue;
    }
}
