/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.List;
import model.Trip;


/**
 *
 * @author USER
 */
public class Service {

    public static void main(String[] args) {

        try {

            System.out.println("Starting RMI Server...");

            Registry registry =
                    LocateRegistry.createRegistry(5000);

            TripService service =
                    new TripServiceImpl() {
                @Override
                public Trip registerTripRecord(Trip theTrip) throws RemoteException {
                    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                }

                @Override
                public Trip updateTripRecord(Trip theTrip) throws RemoteException {
                    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                }

                @Override
                public Trip deleteTripRecord(Trip theTrip) throws RemoteException {
                    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                }

                @Override
                public Trip findTripRecordById(Trip theTrip) throws RemoteException {
                    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                }

                @Override
                public List<Trip> findAllTripRecords() throws RemoteException {
                    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                }
            };

            registry.rebind("trip-service", service);

            System.out.println("Trip Service Registered");

        } catch (Exception ex) {

            ex.printStackTrace();
        }
    }
}
    

