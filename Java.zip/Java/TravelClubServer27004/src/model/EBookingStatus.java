package model;

/**
 * Booking status enumeration
 * FIX: Was completely empty - added all required status values
 */
public enum EBookingStatus {
    PENDING,
    CONFIRMED,
    CANCELLED,
    COMPLETED
}
