package model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;

/**
 * Booking Entity
 * FIX 1: status field changed from raw String to @Enumerated EBookingStatus
 * FIX 2: Added missing serialVersionUID warning fix
 * FIX 3: Updated constructor and getters/setters to use EBookingStatus
 */
@Entity
@Table(name = "bookings")
public class Booking implements Serializable {
    public static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bookingid")
    private int bookingId;

    @Temporal(TemporalType.DATE)
    @Column(name = "booking_date", nullable = false)
    private Date bookingDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EBookingStatus status = EBookingStatus.PENDING;

    @Column(name = "num_seats", nullable = false)
    private int numSeats = 1;

    @Column(name = "total_amount", nullable = false)
    private double totalAmount;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "userid", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "tripid", nullable = false)
    private Trip trip;

    // One Booking -> One Payment  (One-to-One, inverse side)
    @OneToOne(mappedBy = "booking", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Payment payment;

    public Booking() {}

    public Booking(Date bookingDate, int numSeats, User user, Trip trip) {
        this.bookingDate = bookingDate;
        this.numSeats = numSeats;
        this.user = user;
        this.trip = trip;
        this.totalAmount = trip.getPrice() * numSeats;
        this.status = EBookingStatus.PENDING;
    }

    //  Getters & Setters 
    public int getBookingId() { return bookingId; }
    public void setBookingId(int bookingId) { this.bookingId = bookingId; }

    public Date getBookingDate() { return bookingDate; }
    public void setBookingDate(Date bookingDate) { this.bookingDate = bookingDate; }

    public EBookingStatus getStatus() { return status; }
    public void setStatus(EBookingStatus status) { this.status = status; }

    /** Convenience setter that accepts a String (for legacy code compatibility) */
    public void setStatusFromString(String s) { this.status = EBookingStatus.valueOf(s); }

    public int getNumSeats() { return numSeats; }
    public void setNumSeats(int numSeats) { this.numSeats = numSeats; }

    public double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(double totalAmount) { this.totalAmount = totalAmount; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public Trip getTrip() { return trip; }
    public void setTrip(Trip trip) { this.trip = trip; }

    public Payment getPayment() { return payment; }
    public void setPayment(Payment payment) { this.payment = payment; }

    @Override
    public String toString() {
        return "Booking#" + bookingId + " [" + (trip != null ? trip.getDestination() : "?") + "] " + status;
    }
}
