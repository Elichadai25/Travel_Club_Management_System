package view;

import controller.BookingController;
import controller.TripController;
import model.Booking;
import model.EBookingStatus;
import model.Trip;
import model.User;
import util.SessionManager;
import util.UITheme;
import java.awt.*;
import java.text.SimpleDateFormat;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class BookingModule extends JFrame {

    private final DefaultTableModel tableModel = new DefaultTableModel(
        new String[]{"ID", "Member", "Trip", "Seats", "Total ($)", "Status", "Date"}, 0) {
        public boolean isCellEditable(int r, int c) { return false; }
    };
    private static final SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd");

    private JTextField txtId, txtTripId, txtSeats;
    private JComboBox<EBookingStatus> cmbStatus;
    private JTable table;

    public BookingModule() {
        setTitle("Booking Management");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1050, 560);
        setLocationRelativeTo(null);
        initComponents();
        loadTable();
    }

    private void initComponents() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UITheme.BG);

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UITheme.PRIMARY);
        header.setPreferredSize(new Dimension(0, 52));
        header.setBorder(new EmptyBorder(0, 20, 0, 20));
        JLabel lbl = new JLabel("📋  Booking Management");
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lbl.setForeground(Color.WHITE);
        header.add(lbl, BorderLayout.WEST);

        // Form card
        JPanel formCard = new JPanel(new BorderLayout());
        formCard.setBackground(Color.WHITE);
        formCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UITheme.BORDER),
            new EmptyBorder(16, 20, 16, 20)));
        formCard.setPreferredSize(new Dimension(300, 0));

        JPanel fields = new JPanel(new GridBagLayout());
        fields.setBackground(Color.WHITE);
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL; g.gridx = 0;
        g.insets = new Insets(4, 0, 4, 0);

        txtId     = UITheme.styledField(); txtId.setEditable(false);
        txtTripId = UITheme.styledField();
        txtSeats  = UITheme.styledField();
        cmbStatus = new JComboBox<>(EBookingStatus.values());
        cmbStatus.setFont(UITheme.FONT_BODY);
        cmbStatus.setPreferredSize(new Dimension(220, 34));

        String[] labels = {"Booking ID (auto)", "Trip ID *", "Number of Seats *", "Status"};
        JComponent[] flds = {txtId, txtTripId, txtSeats, cmbStatus};
        for (int i = 0; i < labels.length; i++) {
            g.gridy = i * 2;     fields.add(UITheme.fieldLabel(labels[i]), g);
            g.gridy = i * 2 + 1; fields.add(flds[i], g);
        }

        JButton btnBook   = UITheme.successButton("Book Trip");
        JButton btnCancel = UITheme.warningButton("Cancel");
        JButton btnDelete = UITheme.dangerButton("Delete");
        JButton btnClear  = UITheme.secondaryButton("Clear");

        JPanel btns = new JPanel(new GridLayout(2, 2, 8, 8));
        btns.setBackground(Color.WHITE);
        btns.setBorder(new EmptyBorder(14, 0, 0, 0));
        btns.add(btnBook); btns.add(btnCancel);
        btns.add(btnDelete); btns.add(btnClear);

        JPanel inner = new JPanel(new BorderLayout());
        inner.setBackground(Color.WHITE);
        inner.add(UITheme.sectionTitle("New Booking"), BorderLayout.NORTH);
        inner.add(fields, BorderLayout.CENTER);
        inner.add(btns, BorderLayout.SOUTH);
        formCard.add(inner);

        // Table card
        table = new JTable(tableModel);
        UITheme.styleTable(table);
        JPanel tableCard = new JPanel(new BorderLayout());
        tableCard.setBackground(Color.WHITE);
        tableCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UITheme.BORDER),
            new EmptyBorder(12, 12, 12, 12)));
        tableCard.add(UITheme.sectionTitle("Booking History"), BorderLayout.NORTH);
        tableCard.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel body = new JPanel(new BorderLayout(12, 0));
        body.setBackground(UITheme.BG);
        body.setBorder(new EmptyBorder(12, 12, 12, 12));
        body.add(formCard, BorderLayout.WEST);
        body.add(tableCard, BorderLayout.CENTER);

        root.add(header, BorderLayout.NORTH);
        root.add(body, BorderLayout.CENTER);
        setContentPane(root);

        // Actions
        btnBook.addActionListener(e -> {
            if (txtTripId.getText().trim().isEmpty() || txtSeats.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Trip ID and Seats are required.", "Validation", JOptionPane.WARNING_MESSAGE); return;
            }
            try {
                int seats = Integer.parseInt(txtSeats.getText().trim());
                if (seats <= 0) { JOptionPane.showMessageDialog(this, "Seats must be at least 1.", "Validation", JOptionPane.WARNING_MESSAGE); return; }
                User current = SessionManager.getCurrentUser();
                if (current == null) { JOptionPane.showMessageDialog(this, "Not logged in.", "Error", JOptionPane.ERROR_MESSAGE); return; }
                Trip trip = TripController.findById(Integer.parseInt(txtTripId.getText().trim()));
                if (trip == null) { JOptionPane.showMessageDialog(this, "Trip not found.", "Error", JOptionPane.ERROR_MESSAGE); return; }
                Booking b = new Booking(new java.util.Date(), seats, current, trip);
                Booking saved = BookingController.create(b);
                if (saved != null) {
                    JOptionPane.showMessageDialog(this, "Booking created! ID: " + saved.getBookingId(), "Success", JOptionPane.INFORMATION_MESSAGE);
                    loadTable(); clearForm();
                } else {
                    JOptionPane.showMessageDialog(this, "Booking failed. Check available slots.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Trip ID and Seats must be numbers.", "Validation", JOptionPane.WARNING_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnCancel.addActionListener(e -> {
            if (txtId.getText().trim().isEmpty()) { JOptionPane.showMessageDialog(this, "Select a booking first.", "Validation", JOptionPane.WARNING_MESSAGE); return; }
            if (BookingController.cancel(Integer.parseInt(txtId.getText().trim()))) {
                JOptionPane.showMessageDialog(this, "Booking cancelled.", "Success", JOptionPane.INFORMATION_MESSAGE);
                loadTable(); clearForm();
            } else {
                JOptionPane.showMessageDialog(this, "Cancel failed.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnDelete.addActionListener(e -> {
            if (txtId.getText().trim().isEmpty()) { JOptionPane.showMessageDialog(this, "Select a booking first.", "Validation", JOptionPane.WARNING_MESSAGE); return; }
            if (JOptionPane.showConfirmDialog(this, "Delete this booking?", "Confirm", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
            if (BookingController.delete(Integer.parseInt(txtId.getText().trim()))) {
                JOptionPane.showMessageDialog(this, "Booking deleted.", "Success", JOptionPane.INFORMATION_MESSAGE);
                loadTable(); clearForm();
            } else {
                JOptionPane.showMessageDialog(this, "Delete failed.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnClear.addActionListener(e -> clearForm());

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
                int row = table.getSelectedRow();
                txtId.setText(tableModel.getValueAt(row, 0).toString());
                cmbStatus.setSelectedItem(EBookingStatus.valueOf(tableModel.getValueAt(row, 5).toString()));
            }
        });
    }

    private void loadTable() {
        tableModel.setRowCount(0);
        for (Booking b : BookingController.findAll()) {
            tableModel.addRow(new Object[]{
                b.getBookingId(),
                b.getUser() != null ? b.getUser().getFullName() : "",
                b.getTrip() != null ? b.getTrip().getDestination() : "",
                b.getNumSeats(),
                String.format("%.2f", b.getTotalAmount()),
                b.getStatus(),
                b.getBookingDate() != null ? SDF.format(b.getBookingDate()) : ""
            });
        }
    }

    private void clearForm() {
        txtId.setText(""); txtTripId.setText(""); txtSeats.setText("");
        cmbStatus.setSelectedIndex(0); table.clearSelection();
    }

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new BookingModule().setVisible(true));
    }
}
