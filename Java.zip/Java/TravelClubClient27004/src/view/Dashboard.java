/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import util.SessionManager;
import util.UITheme;

/**
 *
 * @author Elichadai
 */
public class Dashboard extends javax.swing.JFrame {

    /**
     * Creates new form Dashboard
     */
    public Dashboard() {
        initComponents();
    
    }
    private JPanel contentPanel;
    private JButton activeBtn;

    public DashboardForm() {
        setTitle("Travel Club Management System");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1200, 720);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(900, 600));
        initComponents();
    }

    private void initComponents() {
        boolean isAdmin = SessionManager.isAdmin();

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UITheme.BG);

        // TOP BAR 
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(UITheme.PRIMARY);
        topBar.setPreferredSize(new Dimension(0, 58));
        topBar.setBorder(new EmptyBorder(0, 20, 0, 20));

        JPanel logoArea = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 14));
        logoArea.setBackground(UITheme.PRIMARY);
        JLabel lblIcon = new JLabel("✈");
        lblIcon.setFont(new Font("Segoe UI", Font.PLAIN, 22));
        lblIcon.setForeground(UITheme.ACCENT);
        JLabel lblApp = new JLabel("Travel Club Management System");
        lblApp.setFont(new Font("Segoe UI", Font.BOLD, 17));
        lblApp.setForeground(Color.WHITE);
        logoArea.add(lblIcon);
        logoArea.add(lblApp);

        JPanel rightTop = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 12));
        rightTop.setBackground(UITheme.PRIMARY);

        String roleLabel = isAdmin ? "🔑 ADMIN" : "👤 MEMBER";
        Color  roleColor = isAdmin ? new Color(255, 200, 50) : new Color(100, 220, 180);

        JLabel lblWelcome = new JLabel("Welcome, " + SessionManager.getCurrentUser().getFullName() + "   |   ");
        lblWelcome.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblWelcome.setForeground(new Color(200, 220, 255));

        JLabel lblRole = new JLabel(roleLabel);
        lblRole.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblRole.setForeground(roleColor);

        JButton btnLogout = new JButton("⏻  Logout");
        btnLogout.setBackground(UITheme.DANGER);
        btnLogout.setForeground(Color.WHITE);
        btnLogout.setFont(UITheme.FONT_BUTTON);
        btnLogout.setFocusPainted(false);
        btnLogout.setBorderPainted(false);
        btnLogout.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnLogout.addActionListener(e -> { SessionManager.logout(); new LoginForm().setVisible(true); dispose(); });

        rightTop.add(lblWelcome);
        rightTop.add(lblRole);
        rightTop.add(btnLogout);
        topBar.add(logoArea, BorderLayout.WEST);
        topBar.add(rightTop, BorderLayout.EAST);

        // SIDEBAR 
// Admin = dark navy, Member = dark teal — visually distinct
        Color sidebarColor = isAdmin ? UITheme.PRIMARY_DARK : new Color(0, 77, 77);

        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(sidebarColor);
        sidebar.setPreferredSize(new Dimension(210, 0));
        sidebar.setBorder(new EmptyBorder(12, 0, 12, 0));

        // Role badge at top of sidebar
        JLabel lblRoleBadge = new JLabel(
            isAdmin ? "  🔑  Administrator" : "  👤  Member",
            SwingConstants.LEFT);
        lblRoleBadge.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblRoleBadge.setForeground(isAdmin ? new Color(255, 200, 50) : new Color(100, 220, 180));
        lblRoleBadge.setMaximumSize(new Dimension(210, 36));
        lblRoleBadge.setBorder(new EmptyBorder(4, 18, 8, 0));
        sidebar.add(lblRoleBadge);
        sidebar.add(Box.createVerticalStrut(4));

        JSeparator sidebarSep = new JSeparator();
        sidebarSep.setMaximumSize(new Dimension(180, 1));
        sidebarSep.setForeground(new Color(255, 255, 255, 40));
        sidebar.add(sidebarSep);
        sidebar.add(Box.createVerticalStrut(6));

        String[][] menuItems = isAdmin
            ? new String[][]{{"🏠","Dashboard"},{"👥","Members"},{"✈","Trips"},
                             {"📋","Bookings"},{"💳","Payments"},{"🔔","Notifications"},{"📊","Reports"}}
            : new String[][]{{"🏠","Dashboard"},{"✈","Trips"},{"📋","Bookings"},{"🔔","Notifications"}};

        for (String[] item : menuItems) {
            JButton btn = createSidebarButton(item[0] + "  " + item[1], sidebarColor);
            sidebar.add(btn);
            sidebar.add(Box.createVerticalStrut(2));
            btn.addActionListener(e -> { setActiveButton(btn); loadPanel(item[1]); });
        }

        // CONTENT 
        contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(UITheme.BG);
        loadPanel("Dashboard");

        root.add(topBar, BorderLayout.NORTH);
        root.add(sidebar, BorderLayout.WEST);
        root.add(contentPanel, BorderLayout.CENTER);
        setContentPane(root);
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jOptionPane1 = new javax.swing.JOptionPane();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Background1.jpeg"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 20, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1072, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 517, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 22, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Dashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JOptionPane jOptionPane1;
    // End of variables declaration//GEN-END:variables

    private JButton createSidebarButton(String string, Color sidebarColor) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void setActiveButton(JButton btn) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void loadPanel(String dashboard) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
