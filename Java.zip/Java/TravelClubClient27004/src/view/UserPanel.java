package view;

import controller.UserController;
import model.EUserRole;
import model.User;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class UserPanel extends JPanel {

    private final DefaultTableModel tableModel = new DefaultTableModel(
        new String[]{"ID", "Full Name", "Email", "Phone", "Role", "Active", "Created At"}, 0) {
        public boolean isCellEditable(int r, int c) { return false; }
    };
    private static final SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private JTextField txtId, txtName, txtEmail, txtPhone, txtPassword;
    private JComboBox<EUserRole> cmbRole;
    private JCheckBox chkActive;
    private JTable table;

    public UserPanel() {
        setLayout(new BorderLayout());
        buildUI();
        loadTable();
    }

    private void buildUI() {
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("User Form"));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(4, 6, 4, 6); g.fill = GridBagConstraints.HORIZONTAL;

        txtId = new JTextField(10); txtId.setEditable(false);
        txtName = new JTextField(15); txtEmail = new JTextField(15);
        txtPhone = new JTextField(15); txtPassword = new JTextField(15);
        cmbRole = new JComboBox<>(EUserRole.values());
        chkActive = new JCheckBox("Active", true);

        String[] labels = {"ID", "Full Name", "Email", "Phone", "Password", "Role"};
        JComponent[] fields = {txtId, txtName, txtEmail, txtPhone, txtPassword, cmbRole};
        for (int i = 0; i < labels.length; i++) {
            g.gridx = 0; g.gridy = i; form.add(new JLabel(labels[i]), g);
            g.gridx = 1; form.add(fields[i], g);
        }
        g.gridx = 1; g.gridy = labels.length; form.add(chkActive, g);

        JButton btnSave = new JButton("Save"); btnSave.setBackground(new Color(102, 255, 102));
        JButton btnUpdate = new JButton("Update"); btnUpdate.setBackground(new Color(255, 255, 153));
        JButton btnDelete = new JButton("Delete"); btnDelete.setBackground(new Color(255, 80, 80)); btnDelete.setForeground(Color.WHITE);
        JButton btnClear = new JButton("Clear");

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 4));
        btns.add(btnSave); btns.add(btnUpdate); btns.add(btnDelete); btns.add(btnClear);

        JPanel left = new JPanel(new BorderLayout());
        left.add(form, BorderLayout.CENTER); left.add(btns, BorderLayout.SOUTH);

        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createTitledBorder("Users"));

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, left, scroll);
        split.setDividerLocation(310);
        add(split, BorderLayout.CENTER);

        btnSave.addActionListener(e -> {
            if (txtName.getText().trim().isEmpty() || txtEmail.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Name and Email are required."); return;
            }
            User u = new User(txtEmail.getText().trim(), txtPassword.getText().trim(),
                    txtName.getText().trim(), txtPhone.getText().trim(), (EUserRole) cmbRole.getSelectedItem());
            u.setActive(chkActive.isSelected());
            if (UserController.save(u)) { JOptionPane.showMessageDialog(this, "User saved."); loadTable(); clearForm(); }
            else JOptionPane.showMessageDialog(this, "Save failed.", "Error", JOptionPane.ERROR_MESSAGE);
        });

        btnUpdate.addActionListener(e -> {
            if (txtId.getText().trim().isEmpty()) { JOptionPane.showMessageDialog(this, "Select a user first."); return; }
            User u = new User(txtEmail.getText().trim(), txtPassword.getText().trim(),
                    txtName.getText().trim(), txtPhone.getText().trim(), (EUserRole) cmbRole.getSelectedItem());
            u.setUserId(Integer.parseInt(txtId.getText().trim()));
            u.setActive(chkActive.isSelected());
            if (UserController.update(u)) { JOptionPane.showMessageDialog(this, "User updated."); loadTable(); clearForm(); }
            else JOptionPane.showMessageDialog(this, "Update failed.", "Error", JOptionPane.ERROR_MESSAGE);
        });

        btnDelete.addActionListener(e -> {
            if (txtId.getText().trim().isEmpty()) { JOptionPane.showMessageDialog(this, "Select a user first."); return; }
            if (JOptionPane.showConfirmDialog(this, "Delete this user?") != JOptionPane.YES_OPTION) return;
            if (UserController.delete(Integer.parseInt(txtId.getText().trim()))) { JOptionPane.showMessageDialog(this, "User deleted."); loadTable(); clearForm(); }
            else JOptionPane.showMessageDialog(this, "Delete failed.", "Error", JOptionPane.ERROR_MESSAGE);
        });

        btnClear.addActionListener(e -> clearForm());

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
                int row = table.getSelectedRow();
                txtId.setText(tableModel.getValueAt(row, 0).toString());
                txtName.setText(tableModel.getValueAt(row, 1).toString());
                txtEmail.setText(tableModel.getValueAt(row, 2).toString());
                txtPhone.setText(tableModel.getValueAt(row, 3).toString());
                cmbRole.setSelectedItem(EUserRole.valueOf(tableModel.getValueAt(row, 4).toString()));
                chkActive.setSelected(Boolean.parseBoolean(tableModel.getValueAt(row, 5).toString()));
            }
        });
    }

    private void loadTable() {
        tableModel.setRowCount(0);
        for (User u : UserController.findAll()) {
            tableModel.addRow(new Object[]{
                u.getUserId(), u.getFullName(), u.getEmail(), u.getPhoneNumber(),
                u.getRole(), u.isActive(),
                ""
            });
        }
    }

    private void clearForm() {
        txtId.setText(""); txtName.setText(""); txtEmail.setText("");
        txtPhone.setText(""); txtPassword.setText("");
        cmbRole.setSelectedIndex(0); chkActive.setSelected(true); table.clearSelection();
    }
}
