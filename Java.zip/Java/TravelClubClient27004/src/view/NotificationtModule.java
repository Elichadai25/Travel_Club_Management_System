package view;

import controller.NotificationController;
import model.Notification;
import util.SessionManager;
import util.UITheme;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class NotificationtModule extends JFrame {

    private final DefaultTableModel tableModel = new DefaultTableModel(
        new String[]{"ID", "Message", "Type", "Read", "Sent At"}, 0) {
        public boolean isCellEditable(int r, int c) { return false; }
    };
    private static final SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private JTable table;
    private JLabel lblCount;

    public NotificationtModule() {
        setTitle("Notifications");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(900, 520);
        setLocationRelativeTo(null);
        initComponents();
        loadTable();
    }

    private void initComponents() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UITheme.BG);

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UITheme.PRIMARY);
        header.setPreferredSize(new Dimension(0, 52));
        header.setBorder(new EmptyBorder(0, 20, 0, 20));
        JLabel lbl = new JLabel("🔔  Notifications");
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lbl.setForeground(Color.WHITE);
        lblCount = new JLabel();
        lblCount.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblCount.setForeground(new Color(200, 220, 255));
        header.add(lbl, BorderLayout.WEST);
        header.add(lblCount, BorderLayout.EAST);

        // Table
        table = new JTable(tableModel);
        UITheme.styleTable(table);
        table.setRowHeight(30);

        // Color unread rows differently via renderer override
        table.getColumnModel().getColumn(3).setCellRenderer((t, val, sel, foc, row, col) -> {
            JLabel cell = new JLabel(val != null ? val.toString() : "");
            cell.setOpaque(true);
            cell.setBorder(new EmptyBorder(0, 10, 0, 10));
            cell.setFont(UITheme.FONT_BODY);
            boolean isRead = "Yes".equals(tableModel.getValueAt(row, 3));
            if (!sel) {
                cell.setBackground(isRead ? (row % 2 == 0 ? Color.WHITE : new Color(248, 250, 253))
                                          : new Color(255, 248, 220));
                cell.setForeground(isRead ? UITheme.TEXT_MUTED : UITheme.WARNING.darker());
            } else {
                cell.setBackground(new Color(210, 228, 255));
                cell.setForeground(UITheme.TEXT_MAIN);
            }
            return cell;
        });

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createEmptyBorder());

        JPanel tableCard = new JPanel(new BorderLayout());
        tableCard.setBackground(Color.WHITE);
        tableCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UITheme.BORDER),
            new EmptyBorder(12, 12, 12, 12)));
        tableCard.add(UITheme.sectionTitle("Notification History"), BorderLayout.NORTH);
        tableCard.add(scroll, BorderLayout.CENTER);

        // Bottom buttons
        JButton btnMarkRead = UITheme.primaryButton("Mark as Read");
        JButton btnRefresh  = UITheme.secondaryButton("Refresh");

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 8));
        btns.setBackground(UITheme.BG);
        btns.add(btnMarkRead);
        btns.add(btnRefresh);

        JPanel body = new JPanel(new BorderLayout());
        body.setBackground(UITheme.BG);
        body.setBorder(new EmptyBorder(12, 12, 0, 12));
        body.add(tableCard, BorderLayout.CENTER);

        root.add(header, BorderLayout.NORTH);
        root.add(body, BorderLayout.CENTER);
        root.add(btns, BorderLayout.SOUTH);
        setContentPane(root);

        btnMarkRead.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { JOptionPane.showMessageDialog(this, "Select a notification first.", "Validation", JOptionPane.WARNING_MESSAGE); return; }
            int id = Integer.parseInt(tableModel.getValueAt(row, 0).toString());
            if (NotificationController.markAsRead(id)) {
                JOptionPane.showMessageDialog(this, "Marked as read.", "Success", JOptionPane.INFORMATION_MESSAGE);
                loadTable();
            }
        });

        btnRefresh.addActionListener(e -> loadTable());
    }

    private void loadTable() {
        tableModel.setRowCount(0);
        model.User current = SessionManager.getCurrentUser();
        List<Notification> list = (current != null)
            ? NotificationController.findByUser(current.getUserId())
            : NotificationController.findAll();

        int unread = 0;
        for (Notification n : list) {
            if (!n.isRead()) unread++;
            tableModel.addRow(new Object[]{
                n.getNotificationId(), n.getMessage(), n.getType(),
                n.isRead() ? "Yes" : "No",
                n.getSentAt() != null ? SDF.format(n.getSentAt()) : ""
            });
        }
        lblCount.setText("  " + unread + " unread  ");
    }

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new NotificationtModule().setVisible(true));
    }
}
