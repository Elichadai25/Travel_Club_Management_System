package view;

import controller.BookingController;
import controller.PaymentController;
import controller.TripController;
import controller.UserController;
import model.Booking;
import model.Payment;
import util.ExportUtil;
import java.awt.*;
import java.text.SimpleDateFormat;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ReportPanel extends JPanel {

    private static final SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private JTable table;
    private DefaultTableModel tableModel;
    private JLabel lblStatus;
    private Image bgImage;

    public ReportPanel() {
        setLayout(new BorderLayout());
        // Load background image
        try {
            java.net.URL imgUrl = getClass().getResource("/images/background.jpeg");
            if (imgUrl != null) {
                bgImage = new ImageIcon(imgUrl).getImage();
            }
        } catch (Exception e) {
            bgImage = null;
        }
        buildUI();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (bgImage != null) {
            g.drawImage(bgImage, 0, 0, getWidth(), getHeight(), this);
            // Add semi-transparent overlay
            g.setColor(new Color(0, 0, 0, 80));
            g.fillRect(0, 0, getWidth(), getHeight());
        }
    }

    private void buildUI() {
        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(26, 60, 110));
        header.setPreferredSize(new Dimension(0, 52));
        header.setBorder(new javax.swing.border.EmptyBorder(0, 20, 0, 20));
        header.setOpaque(true);
        JLabel lblTitle = new JLabel("📊  Reports & Export");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitle.setForeground(Color.WHITE);
        header.add(lblTitle, BorderLayout.WEST);

        // Report buttons panel
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 10));
        top.setBackground(new Color(255, 255, 255, 220));
        top.setOpaque(true);
        top.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(220, 220, 220)),
            new javax.swing.border.EmptyBorder(4, 8, 4, 8)));

        JButton btnUsers    = makeReportBtn("👥 Members",  new Color(41, 128, 185));
        JButton btnTrips    = makeReportBtn("✈ Trips",     new Color(39, 174, 96));
        JButton btnBookings = makeReportBtn("📋 Bookings", new Color(243, 156, 18));
        JButton btnPayments = makeReportBtn("💳 Payments", new Color(192, 57, 43));

        JLabel sep = new JLabel("  |  Export:");
        sep.setFont(new Font("Segoe UI", Font.BOLD, 12));
        sep.setForeground(new Color(100, 100, 100));

        JButton btnCSV  = makeReportBtn("CSV",  new Color(44, 62, 80));
        JButton btnHTML = makeReportBtn("HTML", new Color(44, 62, 80));
        JButton btnPDF  = makeReportBtn("PDF",  new Color(44, 62, 80));

        top.add(btnUsers);
        top.add(btnTrips);
        top.add(btnBookings);
        top.add(btnPayments);
        top.add(sep);
        top.add(btnCSV);
        top.add(btnHTML);
        top.add(btnPDF);

        // Table
        tableModel = new DefaultTableModel() {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(28);
        table.setShowGrid(true);
        table.setGridColor(new Color(220, 220, 220));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(26, 60, 110));
        table.getTableHeader().setForeground(Color.WHITE);
        table.setSelectionBackground(new Color(210, 228, 255));

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createEmptyBorder());

        // Table card with semi-transparent background
        JPanel tableCard = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                g.setColor(new Color(255, 255, 255, 230));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        tableCard.setOpaque(false);
        tableCard.setBorder(new javax.swing.border.EmptyBorder(0, 0, 0, 0));
        tableCard.add(top, BorderLayout.NORTH);
        tableCard.add(scroll, BorderLayout.CENTER);

        // Status bar
        lblStatus = new JLabel("  Select a report to generate.");
        lblStatus.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        lblStatus.setForeground(new Color(80, 80, 80));
        lblStatus.setBorder(new javax.swing.border.EmptyBorder(6, 12, 6, 12));
        lblStatus.setBackground(new Color(240, 240, 240, 200));
        lblStatus.setOpaque(true);

        JPanel body = new JPanel(new BorderLayout(0, 8));
        body.setOpaque(false);
        body.setBorder(new javax.swing.border.EmptyBorder(10, 10, 10, 10));
        body.add(tableCard, BorderLayout.CENTER);

        add(header, BorderLayout.NORTH);
        add(body, BorderLayout.CENTER);
        add(lblStatus, BorderLayout.SOUTH);

        // Actions
        btnUsers.addActionListener(e    -> loadUsersReport());
        btnTrips.addActionListener(e    -> loadTripsReport());
        btnBookings.addActionListener(e -> loadBookingsReport());
        btnPayments.addActionListener(e -> loadPaymentsReport());

        btnCSV.addActionListener(e -> {
            if (table.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "Generate a report first."); return;
            }
            ExportUtil.exportToCSV(table, lblStatus.getText().trim());
        });

        btnHTML.addActionListener(e -> {
            if (table.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "Generate a report first."); return;
            }
            ExportUtil.exportToHTML(table, lblStatus.getText().trim());
        });

        btnPDF.addActionListener(e -> {
            if (table.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "Generate a report first."); return;
            }
            JOptionPane.showMessageDialog(this,
                "PDF export: use Export HTML and print to PDF from your browser.",
                "PDF Export", JOptionPane.INFORMATION_MESSAGE);
        });
    }

    private void loadUsersReport() {
        tableModel.setRowCount(0);
        tableModel.setColumnCount(0);
        tableModel.addColumn("ID");
        tableModel.addColumn("Full Name");
        tableModel.addColumn("Email");
        tableModel.addColumn("Phone");
        tableModel.addColumn("Role");
        tableModel.addColumn("Active");
        UserController.findAll().forEach(u -> tableModel.addRow(new Object[]{
            u.getUserId(), u.getFullName(), u.getEmail(),
            u.getPhoneNumber(), u.getRole(), u.isActive() ? "Yes" : "No"
        }));
        lblStatus.setText("  Members Report — " + tableModel.getRowCount() + " records");
    }

    private void loadTripsReport() {
        tableModel.setRowCount(0);
        tableModel.setColumnCount(0);
        tableModel.addColumn("ID");
        tableModel.addColumn("Destination");
        tableModel.addColumn("Country");
        tableModel.addColumn("Price (RWF)");
        tableModel.addColumn("Slots");
        tableModel.addColumn("Status");
        tableModel.addColumn("Departure Date");
        TripController.findAll().forEach(t -> tableModel.addRow(new Object[]{
            t.getTripId(), t.getDestination(), t.getCountry(),
            String.format("%.0f", t.getPrice()),
            t.getAvailableSlots(), t.getStatus(),
            t.getDepartureDate() != null ? new java.text.SimpleDateFormat("yyyy-MM-dd").format(t.getDepartureDate()) : ""
        }));
        lblStatus.setText("  Trips Report — " + tableModel.getRowCount() + " records");
    }

    private void loadBookingsReport() {
        tableModel.setRowCount(0);
        tableModel.setColumnCount(0);
        tableModel.addColumn("ID");
        tableModel.addColumn("Member");
        tableModel.addColumn("Trip");
        tableModel.addColumn("Seats");
        tableModel.addColumn("Total (RWF)");
        tableModel.addColumn("Status");
        tableModel.addColumn("Booking Date");
        for (Booking b : BookingController.findAll()) {
            tableModel.addRow(new Object[]{
                b.getBookingId(),
                b.getUser() != null ? b.getUser().getFullName() : "",
                b.getTrip() != null ? b.getTrip().getDestination() : "",
                b.getNumSeats(),
                String.format("%.0f", b.getTotalAmount()),
                b.getStatus(),
                b.getBookingDate() != null ? SDF.format(b.getBookingDate()) : ""
            });
        }
        lblStatus.setText("  Bookings Report — " + tableModel.getRowCount() + " records");
    }

    private void loadPaymentsReport() {
        tableModel.setRowCount(0);
        tableModel.setColumnCount(0);
        tableModel.addColumn("ID");
        tableModel.addColumn("Booking ID");
        tableModel.addColumn("Amount (RWF)");
        tableModel.addColumn("Mode");
        tableModel.addColumn("Status");
        tableModel.addColumn("Reference");
        tableModel.addColumn("Payment Date");
        for (Payment p : PaymentController.findAll()) {
            tableModel.addRow(new Object[]{
                p.getPaymentId(),
                p.getBooking() != null ? p.getBooking().getBookingId() : "",
                String.format("%.0f", p.getAmount()),
                p.getPaymentMode(),
                p.getStatus(),
                p.getTransactionRef(),
                p.getPaymentDate() != null ? SDF.format(p.getPaymentDate()) : ""
            });
        }
        double revenue = PaymentController.getTotalRevenue();
        lblStatus.setText("  Payments Report — " + tableModel.getRowCount()
            + " records  |  Total Revenue: RWF " + String.format("%.0f", revenue));
    }

    private JButton makeReportBtn(String text, Color bg) {
        JButton b = new JButton(text);
        b.setBackground(bg);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI", Font.BOLD, 12));
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setOpaque(true);
        b.setPreferredSize(new Dimension(130, 34));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                b.setBackground(bg.darker());
            }
            public void mouseExited(java.awt.event.MouseEvent e) {
                b.setBackground(bg);
            }
        });
        return b;
    }
}