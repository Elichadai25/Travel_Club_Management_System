package view;

import util.SessionManager;
import util.UITheme;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class DashboardForm extends JFrame {

    private JPanel contentPanel;
    private JButton activeBtn;

    public DashboardForm() {
        setTitle("Travel Club Management System");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1200, 720);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(900, 600));
        initComponents();
    }

    private void initComponents() {
        boolean isAdmin = SessionManager.isAdmin();

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UITheme.BG);

        // TOP BAR 
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(UITheme.PRIMARY);
        topBar.setPreferredSize(new Dimension(0, 58));
        topBar.setBorder(new EmptyBorder(0, 20, 0, 20));

        JPanel logoArea = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 14));
        logoArea.setBackground(UITheme.PRIMARY);
        JLabel lblIcon = new JLabel("✈");
        lblIcon.setFont(new Font("Segoe UI", Font.PLAIN, 22));
        lblIcon.setForeground(UITheme.ACCENT);
        JLabel lblApp = new JLabel("Travel Club Management System");
        lblApp.setFont(new Font("Segoe UI", Font.BOLD, 17));
        lblApp.setForeground(Color.WHITE);
        logoArea.add(lblIcon);
        logoArea.add(lblApp);

        JPanel rightTop = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 12));
        rightTop.setBackground(UITheme.PRIMARY);

        String roleLabel = isAdmin ? "🔑 ADMIN" : "👤 MEMBER";
        Color  roleColor = isAdmin ? new Color(255, 200, 50) : new Color(100, 220, 180);

        JLabel lblWelcome = new JLabel("Welcome, " + SessionManager.getCurrentUser().getFullName() + "   |   ");
        lblWelcome.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblWelcome.setForeground(new Color(200, 220, 255));

        JLabel lblRole = new JLabel(roleLabel);
        lblRole.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblRole.setForeground(roleColor);

        JButton btnLogout = new JButton("⏻  Logout");
        btnLogout.setBackground(UITheme.DANGER);
        btnLogout.setForeground(Color.WHITE);
        btnLogout.setFont(UITheme.FONT_BUTTON);
        btnLogout.setFocusPainted(false);
        btnLogout.setBorderPainted(false);
        btnLogout.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnLogout.addActionListener(e -> { SessionManager.logout(); new LoginForm().setVisible(true); dispose(); });

        rightTop.add(lblWelcome);
        rightTop.add(lblRole);
        rightTop.add(btnLogout);
        topBar.add(logoArea, BorderLayout.WEST);
        topBar.add(rightTop, BorderLayout.EAST);

        // SIDEBAR 
// Admin = dark navy, Member = dark teal — visually distinct
        Color sidebarColor = isAdmin ? UITheme.PRIMARY_DARK : new Color(0, 77, 77);

        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(sidebarColor);
        sidebar.setPreferredSize(new Dimension(210, 0));
        sidebar.setBorder(new EmptyBorder(12, 0, 12, 0));

        // Role badge at top of sidebar
        JLabel lblRoleBadge = new JLabel(
            isAdmin ? "  🔑  Administrator" : "  👤  Member",
            SwingConstants.LEFT);
        lblRoleBadge.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblRoleBadge.setForeground(isAdmin ? new Color(255, 200, 50) : new Color(100, 220, 180));
        lblRoleBadge.setMaximumSize(new Dimension(210, 36));
        lblRoleBadge.setBorder(new EmptyBorder(4, 18, 8, 0));
        sidebar.add(lblRoleBadge);
        sidebar.add(Box.createVerticalStrut(4));

        JSeparator sidebarSep = new JSeparator();
        sidebarSep.setMaximumSize(new Dimension(180, 1));
        sidebarSep.setForeground(new Color(255, 255, 255, 40));
        sidebar.add(sidebarSep);
        sidebar.add(Box.createVerticalStrut(6));

        String[][] menuItems = isAdmin
            ? new String[][]{{"🏠","Dashboard"},{"👥","Members"},{"✈","Trips"},
                             {"📋","Bookings"},{"💳","Payments"},{"🔔","Notifications"},{"📊","Reports"}}
            : new String[][]{{"🏠","Dashboard"},{"✈","Trips"},{"📋","Bookings"},{"🔔","Notifications"}};

        for (String[] item : menuItems) {
            JButton btn = createSidebarButton(item[0] + "  " + item[1], sidebarColor);
            sidebar.add(btn);
            sidebar.add(Box.createVerticalStrut(2));
            btn.addActionListener(e -> { setActiveButton(btn); loadPanel(item[1]); });
        }

        // CONTENT 
        contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(UITheme.BG);
        loadPanel("Dashboard");

        root.add(topBar, BorderLayout.NORTH);
        root.add(sidebar, BorderLayout.WEST);
        root.add(contentPanel, BorderLayout.CENTER);
        setContentPane(root);
    }

    private JButton createSidebarButton(String text, Color sidebarBg) {
        JButton btn = new JButton(text);
        btn.setMaximumSize(new Dimension(210, 46));
        btn.setPreferredSize(new Dimension(210, 46));
        btn.setBackground(sidebarBg);
        btn.setForeground(new Color(200, 230, 225));
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setBorder(new EmptyBorder(0, 18, 0, 0));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                if (btn != activeBtn) btn.setBackground(UITheme.PRIMARY_LIGHT);
            }
            public void mouseExited(java.awt.event.MouseEvent e) {
                if (btn != activeBtn) btn.setBackground(sidebarBg);
            }
        });
        return btn;
    }

    private void setActiveButton(JButton btn) {
        if (activeBtn != null) {
            activeBtn.setBackground(SessionManager.isAdmin() ? UITheme.PRIMARY_DARK : new Color(0, 77, 77));
            activeBtn.setForeground(new Color(200, 230, 225));
        }
        activeBtn = btn;
        btn.setBackground(UITheme.ACCENT);
        btn.setForeground(Color.WHITE);
    }

    private void loadPanel(String name) {
        contentPanel.removeAll();
        JPanel panel;
        switch (name) {
            case "Members":       panel = wrapModule(new UserModule()); break;
            case "Trips":         panel = wrapModule(new TripModule()); break;
            case "Bookings":      panel = wrapModule(new BookingModule()); break;
            case "Payments":      panel = wrapModule(new PaymentModule()); break;
            case "Notifications": panel = wrapModule(new NotificationtModule()); break;
            case "Reports":       panel = new ReportPanel(); break;
            default:              panel = buildHomePanel(); break;
        }
        contentPanel.add(panel, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    private JPanel wrapModule(javax.swing.JFrame module) {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(UITheme.BG);
        java.awt.Container content = module.getContentPane();
        module.dispose();
        wrapper.add(content, BorderLayout.CENTER);
        return wrapper;
    }

    private JPanel buildHomePanel() {
        JPanel p = new JPanel(new GridBagLayout()) {
            private final java.awt.image.BufferedImage bg = loadImage("/images/dashboard_bg.jpg");
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (bg != null) {
                    g.drawImage(bg, 0, 0, getWidth(), getHeight(), this);
                    g.setColor(new Color(245, 247, 250, 190));
                    g.fillRect(0, 0, getWidth(), getHeight());
                }
            }
        };
        p.setBackground(UITheme.BG);
        p.setOpaque(true);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 12, 12, 12);

        String[] titles = {"Total Members", "Active Trips", "Total Bookings", "Total Revenue"};
        Color[]  colors = {UITheme.PRIMARY_LIGHT, UITheme.SUCCESS, UITheme.WARNING, UITheme.DANGER};
        String[] icons  = {"👥", "✈", "📋", "💰"};
        String[] values = {
            String.valueOf(controller.UserController.findAll().size()),
            String.valueOf(controller.TripController.findActiveTrips().size()),
            String.valueOf(controller.BookingController.findAll().size()),
            "$" + String.format("%.2f", controller.PaymentController.getTotalRevenue())
        };

        for (int i = 0; i < titles.length; i++) {
            JPanel card = new JPanel(new BorderLayout(0, 6));
            card.setBackground(colors[i]);
            card.setPreferredSize(new Dimension(220, 110));
            card.setBorder(new EmptyBorder(18, 22, 18, 22));

            JLabel ico = new JLabel(icons[i]);
            ico.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 26));
            ico.setForeground(new Color(255, 255, 255, 180));
            ico.setHorizontalAlignment(SwingConstants.RIGHT);

            JLabel lbl = new JLabel(titles[i]);
            lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
            lbl.setForeground(new Color(255, 255, 255, 210));

            JLabel val = new JLabel(values[i]);
            val.setFont(new Font("Segoe UI", Font.BOLD, 30));
            val.setForeground(Color.WHITE);

            JPanel top = new JPanel(new BorderLayout());
            top.setBackground(colors[i]);
            top.add(lbl, BorderLayout.WEST);
            top.add(ico, BorderLayout.EAST);

            card.add(top, BorderLayout.NORTH);
            card.add(val, BorderLayout.CENTER);

            gbc.gridx = i % 2;
            gbc.gridy = i / 2;
            p.add(card, gbc);
        }

        JLabel msg = new JLabel("Welcome back, " + SessionManager.getCurrentUser().getFullName() + "! 👋",
                SwingConstants.CENTER);
        msg.setFont(new Font("Segoe UI", Font.BOLD, 18));
        msg.setForeground(UITheme.PRIMARY);
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        gbc.insets = new Insets(28, 12, 10, 12);
        p.add(msg, gbc);
        return p;
    }

    private static java.awt.image.BufferedImage loadImage(String path) {
        try {
            java.io.InputStream is = DashboardForm.class.getResourceAsStream(path);
            if (is != null) return javax.imageio.ImageIO.read(is);
        } catch (Exception ignored) {}
        return null;
    }
}
