package view;

import controller.AuthController;
import util.UITheme;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class LoginForm extends JFrame {

    private JTextField txtEmail;
    private JPasswordField txtPassword;

    public LoginForm() {
        setTitle("Travel Club Management System — Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(860, 520);
        setLocationRelativeTo(null);
        setResizable(false);
        initComponents();
    }

    private void initComponents() {
        JPanel root = new JPanel(new GridLayout(1, 2));

        // ── LEFT: background image panel ─────────────────────────────────────
        // Place your travel image at:
        //   TravelClubClient27004/src/images/travel_bg.jpg
        JPanel left = new JPanel(new GridBagLayout()) {
            private final BufferedImage bg = loadImage("/images/travel_bg.jpg");
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (bg != null) {
                    g.drawImage(bg, 0, 0, getWidth(), getHeight(), this);
                }
                // dark navy overlay so text stays readable over any image
                Graphics2D g2 = (Graphics2D) g;
                g2.setColor(new Color(20, 45, 90, 200));
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        left.setBackground(UITheme.PRIMARY);
        left.setOpaque(true);

        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0; g.insets = new Insets(6, 20, 6, 20);

        JLabel ico = new JLabel("✈");
        ico.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 60));
        ico.setForeground(UITheme.ACCENT);
        ico.setHorizontalAlignment(SwingConstants.CENTER);

        JLabel title = new JLabel("Travel Club");
        title.setFont(new Font("Segoe UI", Font.BOLD, 32));
        title.setForeground(Color.WHITE);

        JLabel sub = new JLabel("Management System");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        sub.setForeground(new Color(180, 215, 255));

        JSeparator sep = new JSeparator();
        sep.setPreferredSize(new Dimension(180, 1));
        sep.setForeground(UITheme.ACCENT);

        JLabel tagline = new JLabel(
            "<html><div style='text-align:center;color:#b0d0ff;font-size:11px;line-height:1.6'>"
            + "Your journey starts here.<br>Manage trips, bookings &amp; more.</div></html>");
        tagline.setHorizontalAlignment(SwingConstants.CENTER);

        g.gridy = 0; left.add(ico, g);
        g.gridy = 1; left.add(title, g);
        g.gridy = 2; left.add(sub, g);
        g.gridy = 3; left.add(sep, g);
        g.gridy = 4; left.add(tagline, g);

        // ── RIGHT: login form ─────────────────────────────────────────────────
        JPanel right = new JPanel(new GridBagLayout());
        right.setBackground(Color.WHITE);
        right.setBorder(new EmptyBorder(30, 45, 30, 45));

        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = new Insets(5, 0, 5, 0);
        gc.gridx = 0;

        JLabel lblWelcome = new JLabel("Welcome Back!");
        lblWelcome.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblWelcome.setForeground(UITheme.PRIMARY);

        JLabel lblSub = new JLabel("Sign in to your account");
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSub.setForeground(UITheme.TEXT_MUTED);
        lblSub.setBorder(new EmptyBorder(0, 0, 14, 0));

        txtEmail = UITheme.styledField();
        txtEmail.setPreferredSize(new Dimension(310, 38));

        txtPassword = UITheme.styledPassword();
        txtPassword.setPreferredSize(new Dimension(310, 38));

        JButton btnLogin = UITheme.primaryButton("SIGN IN");
        btnLogin.setPreferredSize(new Dimension(310, 42));
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 14));

        JButton btnRegister = new JButton("Don't have an account? Register");
        btnRegister.setBackground(Color.WHITE);
        btnRegister.setForeground(UITheme.PRIMARY_LIGHT);
        btnRegister.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btnRegister.setBorderPainted(false);
        btnRegister.setFocusPainted(false);
        btnRegister.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        gc.gridy = 0; right.add(lblWelcome, gc);
        gc.gridy = 1; right.add(lblSub, gc);
        gc.gridy = 2; right.add(UITheme.fieldLabel("Email Address"), gc);
        gc.gridy = 3; right.add(txtEmail, gc);
        gc.gridy = 4; gc.insets = new Insets(10, 0, 5, 0); right.add(UITheme.fieldLabel("Password"), gc);
        gc.gridy = 5; gc.insets = new Insets(5, 0, 5, 0); right.add(txtPassword, gc);
        gc.gridy = 6; gc.insets = new Insets(18, 0, 6, 0); right.add(btnLogin, gc);
        gc.gridy = 7; gc.insets = new Insets(0, 0, 0, 0); right.add(btnRegister, gc);

        root.add(left);
        root.add(right);
        setContentPane(root);

        btnLogin.addActionListener(e -> AuthController.handleLogin(
                txtEmail.getText().trim(), new String(txtPassword.getPassword()), this));
        btnRegister.addActionListener(e -> { new RegisterForm().setVisible(true); dispose(); });
        txtPassword.addActionListener(e -> btnLogin.doClick());
    }

    /** Loads an image from the classpath (src/images/). Returns null if not found. */
    private static BufferedImage loadImage(String path) {
        try {
            java.io.InputStream is = LoginForm.class.getResourceAsStream(path);
            if (is != null) return ImageIO.read(is);
        } catch (Exception ignored) {}
        return null;
    }

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new LoginForm().setVisible(true));
    }
}
