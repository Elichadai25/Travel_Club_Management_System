package view;

import controller.PaymentController;
import model.Booking;
import model.EPaymentMode;
import model.Payment;
import util.UITheme;
import java.awt.*;
import java.text.SimpleDateFormat;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class PaymentModule extends JFrame {

    private final DefaultTableModel tableModel = new DefaultTableModel(
        new String[]{"ID", "Booking ID", "Amount ($)", "Mode", "Status", "Ref", "Date"}, 0) {
        public boolean isCellEditable(int r, int c) { return false; }
    };
    private static final SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd");

    private JTextField txtId, txtBookingId, txtAmount;
    private JComboBox<EPaymentMode> cmbMode;
    private JLabel lblRevenue;
    private JTable table;

    public PaymentModule() {
        setTitle("Payment Management");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1050, 540);
        setLocationRelativeTo(null);
        initComponents();
        loadTable();
    }

    private void initComponents() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UITheme.BG);

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UITheme.PRIMARY);
        header.setPreferredSize(new Dimension(0, 52));
        header.setBorder(new EmptyBorder(0, 20, 0, 20));
        JLabel lbl = new JLabel("💳  Payment Management");
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lbl.setForeground(Color.WHITE);
        header.add(lbl, BorderLayout.WEST);

        // Revenue badge
        lblRevenue = new JLabel("Total Revenue: $0.00");
        lblRevenue.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblRevenue.setForeground(UITheme.ACCENT);
        header.add(lblRevenue, BorderLayout.EAST);

        // Form card
        JPanel formCard = new JPanel(new BorderLayout());
        formCard.setBackground(Color.WHITE);
        formCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UITheme.BORDER),
            new EmptyBorder(16, 20, 16, 20)));
        formCard.setPreferredSize(new Dimension(300, 0));

        JPanel fields = new JPanel(new GridBagLayout());
        fields.setBackground(Color.WHITE);
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL; g.gridx = 0;
        g.insets = new Insets(4, 0, 4, 0);

        txtId        = UITheme.styledField(); txtId.setEditable(false);
        txtBookingId = UITheme.styledField();
        txtAmount    = UITheme.styledField();
        cmbMode      = new JComboBox<>(EPaymentMode.values());
        cmbMode.setFont(UITheme.FONT_BODY);
        cmbMode.setPreferredSize(new Dimension(220, 34));

        String[] labels = {"Payment ID (auto)", "Booking ID *", "Amount *", "Payment Mode"};
        JComponent[] flds = {txtId, txtBookingId, txtAmount, cmbMode};
        for (int i = 0; i < labels.length; i++) {
            g.gridy = i * 2;     fields.add(UITheme.fieldLabel(labels[i]), g);
            g.gridy = i * 2 + 1; fields.add(flds[i], g);
        }

        JButton btnSave    = UITheme.successButton("Save Payment");
        JButton btnRefresh = UITheme.primaryButton("Refresh");
        JButton btnClear   = UITheme.secondaryButton("Clear");

        JPanel btns = new JPanel(new GridLayout(1, 3, 8, 0));
        btns.setBackground(Color.WHITE);
        btns.setBorder(new EmptyBorder(14, 0, 0, 0));
        btns.add(btnSave); btns.add(btnRefresh); btns.add(btnClear);

        JPanel inner = new JPanel(new BorderLayout());
        inner.setBackground(Color.WHITE);
        inner.add(UITheme.sectionTitle("Record Payment"), BorderLayout.NORTH);
        inner.add(fields, BorderLayout.CENTER);
        inner.add(btns, BorderLayout.SOUTH);
        formCard.add(inner);

        // Table card
        table = new JTable(tableModel);
        UITheme.styleTable(table);
        JPanel tableCard = new JPanel(new BorderLayout());
        tableCard.setBackground(Color.WHITE);
        tableCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UITheme.BORDER),
            new EmptyBorder(12, 12, 12, 12)));
        tableCard.add(UITheme.sectionTitle("Payment History"), BorderLayout.NORTH);
        tableCard.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel body = new JPanel(new BorderLayout(12, 0));
        body.setBackground(UITheme.BG);
        body.setBorder(new EmptyBorder(12, 12, 12, 12));
        body.add(formCard, BorderLayout.WEST);
        body.add(tableCard, BorderLayout.CENTER);

        root.add(header, BorderLayout.NORTH);
        root.add(body, BorderLayout.CENTER);
        setContentPane(root);

        btnSave.addActionListener(e -> {
            if (txtBookingId.getText().trim().isEmpty() || txtAmount.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Booking ID and Amount are required.", "Validation", JOptionPane.WARNING_MESSAGE); return;
            }
            try {
                double amount = Double.parseDouble(txtAmount.getText().trim());
                if (amount <= 0) { JOptionPane.showMessageDialog(this, "Amount must be greater than 0.", "Validation", JOptionPane.WARNING_MESSAGE); return; }
                Booking booking = new Booking();
                booking.setBookingId(Integer.parseInt(txtBookingId.getText().trim()));
                Payment p = new Payment(amount, new java.util.Date(), (EPaymentMode) cmbMode.getSelectedItem(), booking);
                Payment saved = PaymentController.create(p);
                if (saved != null) {
                    JOptionPane.showMessageDialog(this, "Payment saved!\nRef: " + saved.getTransactionRef(), "Success", JOptionPane.INFORMATION_MESSAGE);
                    loadTable(); clearForm();
                } else {
                    JOptionPane.showMessageDialog(this, "Payment failed. Booking may already be paid.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Amount and Booking ID must be valid numbers.", "Validation", JOptionPane.WARNING_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnRefresh.addActionListener(e -> loadTable());
        btnClear.addActionListener(e -> clearForm());

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
                int row = table.getSelectedRow();
                txtId.setText(tableModel.getValueAt(row, 0).toString());
                txtBookingId.setText(tableModel.getValueAt(row, 1).toString());
                txtAmount.setText(tableModel.getValueAt(row, 2).toString());
            }
        });
    }

    private void loadTable() {
        tableModel.setRowCount(0);
        for (Payment p : PaymentController.findAll()) {
            tableModel.addRow(new Object[]{
                p.getPaymentId(),
                p.getBooking() != null ? p.getBooking().getBookingId() : "",
                String.format("%.2f", p.getAmount()),
                p.getPaymentMode(), p.getStatus(),
                p.getTransactionRef(),
                p.getPaymentDate() != null ? SDF.format(p.getPaymentDate()) : ""
            });
        }
        lblRevenue.setText("  Total Revenue: $" + String.format("%.2f", PaymentController.getTotalRevenue()) + "  ");
    }

    private void clearForm() {
        txtId.setText(""); txtBookingId.setText(""); txtAmount.setText("");
        cmbMode.setSelectedIndex(0); table.clearSelection();
    }

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new PaymentModule().setVisible(true));
    }
}
